﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Generator : MonoBehaviour {
    public GameObject player;
    public GameObject obsPrefab1, obsPrefab2, obsPrefab3;

    private int whatToSpawn;
    private float spawnRate = 5f;
    private float nextSpawn = 0f;
    private Vector3 range;
    private float xRange;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if(Time.time > nextSpawn)
        {
            whatToSpawn = Random.Range(1, 4);
            xRange = Random.Range( -10.0f, 8.0f);
            Debug.Log(xRange);
            switch (whatToSpawn)
            {
                case 1:
                    Instantiate(obsPrefab1, player.transform.position + xRange, Quaternion.identity);
            }
        }
	}
}
