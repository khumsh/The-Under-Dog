﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mover : MonoBehaviour
{   

    public Animator dogAnimator;
    public Rigidbody dogrb;
    public float speed = 10f;
    public bool camSwitch = false;
    public Camera ForwardCam, BackCam;

    private int jumpCount = 0;
 

    private bool isGrounded = true;


    // Use this for initialization
    void Start()
    {
        dogrb = GetComponent<Rigidbody>();
        dogAnimator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        
        float xInput = Input.GetAxis("Horizontal");
        float xSpeed = xInput * 5f;
        Vector3 dogVector = new Vector3(xSpeed, 0, speed);
        dogrb.velocity = dogVector;


        if (Input.GetKeyDown(KeyCode.LeftShift))
        {
            dogAnimator.SetBool("Run", true);
            speed *= 2;
        } else if (Input.GetKeyUp(KeyCode.LeftShift))
        {
            dogAnimator.SetBool("Run", false);
            speed /= 2;
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            camSwitch = !camSwitch;
            ForwardCam.gameObject.SetActive(!camSwitch);
            BackCam.gameObject.SetActive(camSwitch);
        } else if (Input.GetKeyUp(KeyCode.Space))
        {
            camSwitch = !camSwitch;
            ForwardCam.gameObject.SetActive(!camSwitch);
            BackCam.gameObject.SetActive(camSwitch);
        }
        if (Input.GetKeyDown(KeyCode.UpArrow) && jumpCount < 2)
        {
            dogrb.AddForce(Vector3.up * 1000, ForceMode.Impulse);
            dogAnimator.SetBool("Jump", true);
            isGrounded = false;
            jumpCount++;
            
            
        }
    }
    void OnTriggerEnter(Collider col)
    {
        if(col.tag == "Ground")
        {
            isGrounded = true;
            dogAnimator.SetBool("Jump", false);
            jumpCount = 0;
        }
    }
}
